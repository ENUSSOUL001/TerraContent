#ifndef METEORITE_H
#define METEORITE_H

class World;
class Random;

void genMeteorite(Random &rnd, World &world);

#endif // METEORITE_H
