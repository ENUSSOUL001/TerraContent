#ifndef HIVEQUEEN_GLOWINGMOSS_H
#define HIVEQUEEN_GLOWINGMOSS_H

class World;
class Random;

void genGlowingMossHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_GLOWINGMOSS_H
