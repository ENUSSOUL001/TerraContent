#ifndef GLOWINGMUSHROOM_H
#define GLOWINGMUSHROOM_H

class World;
class Random;

void genGlowingMushroom(Random &rnd, World &world);

#endif // GLOWINGMUSHROOM_H
