#ifndef CELEBRATION_ASTEROIDFIELD_H
#define CELEBRATION_ASTEROIDFIELD_H

class World;
class Random;

void genAsteroidFieldCelebration(Random &rnd, World &world);

#endif // CELEBRATION_ASTEROIDFIELD_H
