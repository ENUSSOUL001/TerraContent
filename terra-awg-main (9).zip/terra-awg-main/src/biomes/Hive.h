#ifndef HIVE_H
#define HIVE_H

class World;
class Random;

void fillHive(int hiveX, int hiveY, Random &rnd, World &world);
void fillHive(int hiveX, int hiveY, double size, Random &rnd, World &world);
void genHive(Random &rnd, World &world);

#endif // HIVE_H
