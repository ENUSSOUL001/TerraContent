#ifndef MUSHROOMCABIN_H
#define MUSHROOMCABIN_H

class World;
class Random;

void genMushroomCabin(Random &rnd, World &world);

#endif // MUSHROOMCABIN_H
