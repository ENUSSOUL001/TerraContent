#ifndef SURFACEIGLOO_H
#define SURFACEIGLOO_H

class World;
class Random;

void genIgloo(Random &rnd, World &world);

#endif // SURFACEIGLOO_H
