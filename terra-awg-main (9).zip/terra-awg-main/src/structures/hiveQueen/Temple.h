#ifndef HIVEQUEEN_TEMPLE_H
#define HIVEQUEEN_TEMPLE_H

class World;
class Random;

void genTempleHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_TEMPLE_H
