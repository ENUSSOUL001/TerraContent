#ifndef GLOBALECHO_H
#define GLOBALECHO_H

class World;
class Random;

void genGlobalEcho(Random &rnd, World &world);

#endif // GLOBALECHO_H
