#ifndef CAVERNSPAWN_H
#define CAVERNSPAWN_H

class World;
class Random;

void genCavernSpawn(Random &rnd, World &world);

#endif // CAVERNSPAWN_H
