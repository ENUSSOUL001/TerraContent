#ifndef STARTERHOME_H
#define STARTERHOME_H

class World;
class Random;

void genStarterHome(Random &rnd, World &world);

#endif // STARTERHOME_H
