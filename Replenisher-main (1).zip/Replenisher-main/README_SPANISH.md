# Replenisher
Un Plugin de Tshock que permite regenerar Recursos y Otras cosas en tu Mundo etc.

## Permisos y Comandos
|Permisos     | Comandos    |
|-------------|-------------|
|tshock.world.causeevents  |replen|
|tshock.world.causeevents  |replenreload |
