# Replenisher

If you want to read this in another language: [Spanish](https://github.com/Soof4/Replenisher/blob/main/README_SPANISH.md)

A TShock plugin that replenish world resources.

## Permissions and Commands
|Permissions  | Commands    |
|-------------|-------------|
|tshock.world.causeevents  |replen|
|tshock.world.causeevents  |replenreload |
