### 添加插件
- [ ] 插件已加入解决方案 (Plugin.sln)
- [ ] 插件项目已导入template.targets (<Import Project="..\template.targets"/>)
- [ ] 插件信息已添加至对应manifest.json
- [ ] 插件的文件夹名字和插件的插件项目名字一样 (XXX/XXX.csproj)  
- [ ] 添加插件单独的README.md文件 (XXX/README.md)
- [ ] 插件可以正常工作
### 更新插件/修复BUG
- [ ] 插件已修改版本号
- [ ] 更新插件README.md中的更新日志
- [ ] 插件可以正常工作
### 其他
- [ ] ❤️熙恩我喜欢你
