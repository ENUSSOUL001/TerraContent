﻿namespace AutoReset;

internal enum Status
{
    Available,
    Generating,
    Cleaning
}