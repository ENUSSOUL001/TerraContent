# Back

- Authors: Megghy，肝帝熙恩
- Source: TShock QQ Group
- It can return to the player’s last death location and allows for customizable cooldown time.

## Commands

| Command | Permission |         Details          |
|---------|:----------:|:------------------------:|
| /back   |    back    | Return to Death Location |

## Config
> Configuration file location：tshock/Back.en-US.json
```json5
{
  "CD": 20 //Cool Down Time
}
```

## FeedBack
- Github Issue -> TShockPlugin Repo: https://github.com/UnrealMultiple/TShockPlugin
- TShock QQ Group: 816771079
- China Terraria Forum: trhub.cn, bbstr.net, tr.monika.love
