﻿

namespace Economics.Core.Enumerates;
public enum CurrencyConvertType
{
    Add,

    Deduct
}
