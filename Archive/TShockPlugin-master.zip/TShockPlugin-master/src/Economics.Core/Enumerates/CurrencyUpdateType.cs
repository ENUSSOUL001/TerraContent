﻿

namespace Economics.Core.Enumerates;

public enum CurrencyUpdateType
{
    Added,

    Delete
}