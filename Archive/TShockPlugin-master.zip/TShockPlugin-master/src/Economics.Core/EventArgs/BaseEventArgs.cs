﻿namespace Economics.Core.EventArgs;

public class BaseEventArgs
{
    public bool Handler { get; set; } = false;
}