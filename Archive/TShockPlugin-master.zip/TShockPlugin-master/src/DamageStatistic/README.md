# DamageStatistic 伤害统计

- 作者: Megghy
- 出处: 无
- 在击杀 Boss 后，统计玩家对 boss 造成的伤害

## 更新日志

### v1.0.1
- i18n预备

## 指令

无

## 配置

```json
无
```
## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love