# DamageStatistic

- author: Megghy
- source: None
- After killing the boss, count the damage caused by the player to the boss

## Instruction

none

## Configuration

```json
none
```
## Feedback
- Github Issue -> TShockPlugin Repo: https://github.com/UnrealMultiple/TShockPlugin
- TShock QQ Group: 816771079
- China Terraria Forum: trhub.cn, bbstr.net, tr.monika.love
