# DumpPluginsList

Export the list of plugins for APM.

## 更新日志
### v1.1.0
- 多语言插件描述支持
### v1.0.0
- 添加插件