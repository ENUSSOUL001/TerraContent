# DumpTerrariaID

- author: 少司命
- source: none
- Consolidate and output Terraria internal IDs to a file

## Instruction

| Command      |   Permissions    |  Description   |
|---------|:-------:|:-----:|
| /dumpid | dump.id | Output to file |

## Configuration
> Configuration file location: tshock/TerrariaID.json
```json5
TerrariaID表
```

## Feedback
- Github Issue -> TShockPlugin Repo: https://github.com/UnrealMultiple/TShockPlugin
- TShock QQ Group: 816771079
- China Terraria Forum: trhub.cn, bbstr.net, tr.monika.love
