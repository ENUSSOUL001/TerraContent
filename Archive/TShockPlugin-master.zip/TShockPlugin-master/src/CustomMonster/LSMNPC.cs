﻿namespace CustomMonster;

public class LSMNPC
{
    public int ID { get; set; }

    public string M { get; set; }

    public LSMNPC(int id, string m)
    {
        this.ID = id;
        this.M = m;
    }
}

