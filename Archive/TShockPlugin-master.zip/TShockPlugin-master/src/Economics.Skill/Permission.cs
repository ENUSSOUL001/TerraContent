﻿namespace Economics.Skill;

public class Permission
{
    public const string SkillUse = "economics.skill.use";

    public const string SkillAdmin = "economics.skill.admin";
}