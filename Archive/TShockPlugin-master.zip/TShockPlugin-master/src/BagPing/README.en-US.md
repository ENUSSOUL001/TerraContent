# BagPing

- Authors: Cai
- Source: [github](https://github.com/THEXN/CaiPlugins)
- Mark the dropped Boss bags on the map (60 seconds).


## FeedBack
- Github Issue -> TShockPlugin Repo: https://github.com/UnrealMultiple/TShockPlugin
- TShock QQ Group: 816771079
- China Terraria Forum: trhub.cn, bbstr.net, tr.monika.love