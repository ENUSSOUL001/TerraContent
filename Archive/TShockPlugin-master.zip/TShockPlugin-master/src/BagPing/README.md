# BagPing 地图上标记宝藏袋

- 作者: Cai
- 出处: [github](https://github.com/THEXN/CaiPlugins)
- 在小地图上标记掉落的宝藏袋

## 指令

```
暂无
```

## 配置

```
暂无
```

## 更新日志


### v2025.6.1
- 可以显示护卫勋章掉落
- 添加物品图标
- 改用`DropBossBag`钩子更加准确
### v1.0.3 
- 添加英文翻译
### v1.0.1
- 修改了描述

## 反馈
- 优先发issued -> 共同维护的插件库：https://github.com/UnrealMultiple/TShockPlugin
- 次优先：TShock官方群：816771079
- 大概率看不到但是也可以：国内社区trhub.cn ，bbstr.net , tr.monika.love