# BedSet

- Author: pang2333
- Use the recall item to set the respawn point, and teleport there upon logout or death
  

## Command

| Command |  Permission   |     Details     |
|---------|:-------------:|:---------------:|
| /shome	 | bed.spawn.set | set spawn point |


## Config
> Configuration file location：tshock/Bed.en-US.json
```json5
{
  "SpawnOption": {} //Spawn Point
}
```
## FeedBack
- Github Issue -> TShockPlugin Repo: https://github.com/UnrealMultiple/TShockPlugin
- TShock QQ Group: 816771079
- China Terraria Forum: trhub.cn, bbstr.net, tr.monika.love