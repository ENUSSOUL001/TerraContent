# ChestRestore

- Author: Anonymous, modified by Cjx, and slightly modified by 肝帝熙恩
- Source: None
- Infinite Chest Plugin; after installation, all chests can be taken from infinitely and cannot be changed
- Players with the `chest.name` permission can change the chest name
- Use `/chestedit` to toggle personal mode for editing chest name and contents


## Commands

| Command     | Permission |          Details          |
| --------- | :---------: | :----------------: |
| None | chest.name |   Players with the permission can change the chest name   |
|/chestedit or /ce or /修改箱子 | chest.edit |   Switch to personal mode for editing chest name and contents   |

## Config

```json    
None
```

## FeedBack
- Github Issue -> TShockPlugin Repo: https://github.com/UnrealMultiple/TShockPlugin
- TShock QQ Group: 816771079
- China Terraria Forum: trhub.cn, bbstr.net, tr.monika.love
