﻿namespace CaiBotLite.Enums;

public enum RankTypes
{
    Boss,
    Death,
    Online,
    Fishing,
    EconomicCoin,
    // EconomicLevel,
    Unknown
}