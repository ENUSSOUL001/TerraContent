#ifndef ITEM_H
#define ITEM_H

class Item
{
public:
    int id;
    int prefix;
    int stack;
};

#endif // ITEM_H
