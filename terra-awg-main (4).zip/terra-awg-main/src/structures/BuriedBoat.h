#ifndef BURIEDBOAT_H
#define BURIEDBOAT_H

class World;
class Random;

void genBuriedBoat(Random &rnd, World &world);

#endif // BURIEDBOAT_H
