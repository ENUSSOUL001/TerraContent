#ifndef JUNGLE_H
#define JUNGLE_H

class World;
class Random;

void levitateIslands(int lb, int ub, Random &rnd, World &world);
void genJungle(Random &rnd, World &world);

#endif // JUNGLE_H
