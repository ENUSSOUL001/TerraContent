#ifndef GEMCAVE_H
#define GEMCAVE_H

class World;
class Random;

void genGemCave(Random &rnd, World &world);

#endif // GEMCAVE_H
