#ifndef GEMGROVE_H
#define GEMGROVE_H

class World;
class Random;

void genGemGrove(Random &rnd, World &world);

#endif // GEMGROVE_H
