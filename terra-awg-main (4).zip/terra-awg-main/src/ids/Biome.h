#ifndef BIOME_H
#define BIOME_H

enum class Biome { forest, snow, desert, jungle, underworld };

#endif // BIOME_H
