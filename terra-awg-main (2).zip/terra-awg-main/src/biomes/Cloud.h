#ifndef CLOUD_H
#define CLOUD_H

class World;
class Random;

void genCloud(Random &rnd, World &world);

#endif // CLOUD_H
