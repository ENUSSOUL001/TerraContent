#ifndef PATCHES_BASE_H
#define PATCHES_BASE_H

class World;
class Random;

void genWorldBasePatches(Random &rnd, World &world);

#endif // PATCHES_BASE_H
