#ifndef PATCHES_HIVE_H
#define PATCHES_HIVE_H

class World;
class Random;

void genHivePatches(Random &rnd, World &world);

#endif // PATCHES_HIVE_H
