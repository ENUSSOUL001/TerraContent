#ifndef PYRAMID_H
#define PYRAMID_H

class World;
class Random;

void genPyramid(Random &rnd, World &world);

#endif // PYRAMID_H
