#ifndef TEMPLE_H
#define TEMPLE_H

class World;
class Random;

void genTemple(Random &rnd, World &write_world, const World &read_world);

#endif // TEMPLE_H
