#ifndef TEMPLE_H
#define TEMPLE_H

class World;
class Random;

void genTemple(Random &rnd, World &world);

#endif // TEMPLE_H
