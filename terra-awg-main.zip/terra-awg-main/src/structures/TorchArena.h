#ifndef TORCHARENA_H
#define TORCHARENA_H

class World;
class Random;

void genTorchArena(Random &rnd, World &write_world, const World &read_world);

#endif // TORCHARENA_H
