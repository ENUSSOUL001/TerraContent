#ifndef MUSHROOMCABIN_H
#define MUSHROOMCABIN_H

class World;
class Random;

void genMushroomCabin(Random &rnd, World &write_world, const World &read_world);

#endif // MUSHROOMCABIN_H
