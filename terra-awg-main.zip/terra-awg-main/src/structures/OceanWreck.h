#ifndef OCEANWRECK_H
#define OCEANWRECK_H

class World;
class Random;

void genOceanWreck(Random &rnd, World &write_world, const World &read_world);

#endif // OCEANWRECK_H
