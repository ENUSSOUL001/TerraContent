#ifndef MINECARTTRACKS_H
#define MINECARTTRACKS_H

class World;
class Random;

void genTracks(Random &rnd, World &world);

#endif // MINECARTTRACKS_H
