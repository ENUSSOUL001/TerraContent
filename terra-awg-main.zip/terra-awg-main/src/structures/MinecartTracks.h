#ifndef MINECARTTRACKS_H
#define MINECARTTRACKS_H

class World;
class Random;

void genTracks(Random &rnd, World &write_world, const World &read_world);

#endif // MINECARTTRACKS_H
