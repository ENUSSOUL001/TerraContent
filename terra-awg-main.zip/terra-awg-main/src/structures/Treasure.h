#ifndef TREASURE_H
#define TREASURE_H

#include "structures/StructureUtil.h"

class World;
class Random;

LocationBins genTreasure(Random &rnd, World &write_world, const World &read_world);

#endif // TREASURE_H
