#ifndef SPIDERHALL_H
#define SPIDERHALL_H

class World;
class Random;

void genSpiderHall(Random &rnd, World &write_world, const World &read_world);

#endif // SPIDERHALL_H
