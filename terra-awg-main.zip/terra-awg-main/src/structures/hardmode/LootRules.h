#ifndef HARDMODE_LOOTRULES_H
#define HARDMODE_LOOTRULES_H

class World;

void applyHardmodeLoot(World &write_world);

#endif // HARDMODE_LOOTRULES_H
