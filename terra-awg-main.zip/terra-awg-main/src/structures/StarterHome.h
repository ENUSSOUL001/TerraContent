#ifndef STARTERHOME_H
#define STARTERHOME_H

class World;
class Random;

void genStarterHome(Random &rnd, World &write_world, const World &read_world);

#endif // STARTERHOME_H
