#ifndef SURFACEIGLOO_H
#define SURFACEIGLOO_H

class World;
class Random;

void genIgloo(Random &rnd, World &write_world, const World &read_world);

#endif // SURFACEIGLOO_H
