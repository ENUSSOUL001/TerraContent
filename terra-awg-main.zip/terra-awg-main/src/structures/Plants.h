#ifndef PLANTS_H
#define PLANTS_H

#include "structures/StructureUtil.h"

class World;
class Random;

void genPlants(const LocationBins &locations, Random &rnd, World &write_world, const World &read_world);
void genGrasses(const LocationBins &locations, Random &rnd, World &write_world, const World &read_world);

#endif // PLANTS_H
