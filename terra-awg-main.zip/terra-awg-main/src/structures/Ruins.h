#ifndef RUINS_H
#define RUINS_H

class World;
class Random;

void genRuins(Random &rnd, World &write_world, const World &read_world);

#endif // RUINS_H
