#ifndef RUINS_H
#define RUINS_H

class World;
class Random;

void genRuins(Random &rnd, World &world);

#endif // RUINS_H
