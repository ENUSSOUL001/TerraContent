#ifndef LAKE_H
#define LAKE_H

class Random;
class World;

void genLake(Random &rnd, World &write_world, const World &read_world);

#endif // LAKE_H
