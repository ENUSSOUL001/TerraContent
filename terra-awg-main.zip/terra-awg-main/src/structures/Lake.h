#ifndef LAKE_H
#define LAKE_H

class Random;
class World;

void genLake(Random &rnd, World &world);

#endif // LAKE_H
