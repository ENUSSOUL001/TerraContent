#ifndef DUNGEON_H
#define DUNGEON_H

class World;
class Random;

int computeDungeonCenter(World &world);
void genDungeon(Random &rnd, World &write_world, const World &read_world);

#endif // DUNGEON_H
