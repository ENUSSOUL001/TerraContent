#ifndef VINES_H
#define VINES_H

class World;
class Random;

void genVines(Random &rnd, World &write_world, const World &read_world);

#endif // VINES_H
