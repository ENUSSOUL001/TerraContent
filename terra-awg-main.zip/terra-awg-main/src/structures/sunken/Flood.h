#ifndef FLOOD_H
#define FLOOD_H

class World;

void genFlood(World &write_world);

#endif // FLOOD_H
