#ifndef DESERTTOMB_H
#define DESERTTOMB_H

class World;
class Random;

void genDesertTomb(Random &rnd, World &write_world, const World &read_world);

#endif // DESERTTOMB_H
