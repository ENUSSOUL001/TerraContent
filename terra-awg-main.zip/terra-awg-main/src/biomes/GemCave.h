#ifndef GEMCAVE_H
#define GEMCAVE_H

class World;
class Random;

void genGemCave(Random &rnd, World &write_world, const World &read_world);

#endif // GEMCAVE_H
