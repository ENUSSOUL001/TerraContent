#ifndef HIVE_H
#define HIVE_H

class World;
class Random;

void fillHive(int hiveX, int hiveY, Random &rnd, World &world);
void genHive(Random &rnd, World &write_world, const World &read_world);

#endif // HIVE_H
