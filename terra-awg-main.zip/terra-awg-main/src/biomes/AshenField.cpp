#include "AshenField.h"

#include "Config.h"
#include "Random.h"
#include "World.h"
#include "ids/WallID.h"
#include "structures/StructureUtil.h"
#include "vendor/frozen/set.h"
#include <algorithm>
#include <iostream>

void genAshenField(Random &rnd, World &write_world, const World &read_world)
{
    if (rnd.getDouble(0, 1) > 0.7) {
        return;
    }
    double width = 100 + write_world.getWidth() / rnd.getInt(64, 85);
    if (write_world.conf.shattered) {
        width *= 0.82;
    }
    int minX = write_world.getWidth() / 2 - width;
    int maxX = write_world.getWidth() / 2 + width;
    int minY = std::min(
                   {write_world.spawnY,
                    write_world.getSurfaceLevel(minX),
                    write_world.getSurfaceLevel(maxX)}) -
               20;
    int maxY = std::midpoint<double>(minY + width, write_world.getUndergroundLevel());
    constexpr auto avoidTiles = frozen::make_set<int>({
        TileID::snow,
        TileID::sandstone,
        TileID::marble,
        TileID::jungleGrass,
        TileID::livingWood,
    });
    if (!read_world.regionPasses(
            minX,
            minY,
            maxX - minX,
            maxY - minY,
            [&avoidTiles](const Tile &tile) {
                return !avoidTiles.contains(tile.blockID);
            })) {
        return;
    }
    std::cout << "Managing wildfire\n";
    rnd.shuffleNoise();
    std::map<int, int> underworldWalls;
    for (int wallId : WallVariants::dirt) {
        underworldWalls[wallId] = rnd.select(WallVariants::underworld);
    }
    std::map<int, int> stoneWalls;
    for (int wallId : WallVariants::dirt) {
        stoneWalls[wallId] = rnd.select(WallVariants::stone);
    }
    double height = maxY - write_world.spawnY;
    for (int x = minX; x < maxX; ++x) {
        int surface = scanWhileEmpty({x, minY}, {0, 1}, read_world).second;
        surface = std::lerp(
            write_world.spawnY,
            surface < write_world.getUndergroundLevel() ? surface
                                                  : write_world.getSurfaceLevel(x),
            std::abs(x - write_world.getWidth() / 2) / width);
        for (int y = minY; y < maxY; ++y) {
            double threshold = std::hypot(
                (x - write_world.getWidth() / 2) / width,
                (y - write_world.spawnY) / height);
            if (rnd.getFineNoise(x, y) < 9 * threshold - 8) {
                continue;
            }
            const Tile &readTile = read_world.getTile(x, y);
            Tile &writeTile = write_world.getTile(x, y);
            writeTile = readTile;
            
            if (y <= surface) {
                writeTile.blockID = TileID::empty;
                writeTile.wallID = WallID::empty;
                continue;
            }
            if (threshold > 0.2 && std::abs(rnd.getCoarseNoise(3 * x, 3 * y)) <
                                       std::min(1.0, 5.8 - 7 * threshold) *
                                           (0.05 + 0.3 * (y - minY) / height)) {
                writeTile.blockID = TileID::empty;
                writeTile.wallID = y > surface + 2 ? underworldWalls[writeTile.wallID]
                                              : WallID::empty;
                if (y > surface + 1) {
                    writeTile.liquid = Liquid::lava;
                }
                continue;
            }
            switch (writeTile.blockID) {
            case TileID::dirt:
            case TileID::grass:
                writeTile.blockID = TileID::ash;
                break;
            case TileID::empty:
            case TileID::stone:
            case TileID::mud:
            case TileID::sand:
            case TileID::clay:
                writeTile.blockID =
                    y > write_world.spawnY + 10 ? TileID::obsidian : TileID::ash;
                break;
            default:
                break;
            }
            if (writeTile.blockID == TileID::ash) {
                if (y - 3 < surface &&
                    read_world.getTile(x, y - 1).blockID == TileID::empty) {
                    writeTile.blockID = TileID::ashGrass;
                } else {
                    writeTile.wallID = underworldWalls[writeTile.wallID];
                }
            } else if (writeTile.blockID == TileID::obsidian) {
                writeTile.wallID = stoneWalls[writeTile.wallID];
            }
        }
    }
}
