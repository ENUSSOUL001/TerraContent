#ifndef UNDERWORLD_H
#define UNDERWORLD_H

class World;
class Random;

void genUnderworld(Random &rnd, World &write_world, const World &read_world);

#endif // UNDERWORLD_H
