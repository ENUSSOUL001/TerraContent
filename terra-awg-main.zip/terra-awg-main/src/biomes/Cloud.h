#ifndef CLOUD_H
#define CLOUD_H

class World;
class Random;

void genCloud(Random &rnd, World &write_world, const World &read_world);

#endif // CLOUD_H
