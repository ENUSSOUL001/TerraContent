#include "Base.h"

#include "Config.h"
#include "Random.h"
#include "Util.h"
#include "World.h"
#include "biomes/BiomeUtil.h"
#include "ids/WallID.h"
#include <algorithm>
#include <iostream>
#include <map>
#include <mutex>

void computeSurfaceLevel(Random &rnd, World &world)
{
    double surfaceLevel = rnd.getDouble(
        0.7 * world.getUndergroundLevel(),
        0.8 * world.getUndergroundLevel());
    int center = world.getWidth() / 2;
    int delta = 0;
    int deltaLen = 1;
    int prevY = surfaceLevel;
    // Keep surface terrain mostly level near spawn and oceans.
    for (int x = 0; x < world.getWidth(); ++x) {
        double drop =
            world.conf.sunken && !world.conf.shattered
                ? 120 * (1 / (1 + std::exp(0.057 * (180 + center - x))) +
                         1 / (1 + std::exp(0.057 * (180 + x - center)))) -
                      90
                : 0;
        int curY = surfaceLevel + drop +
                   std::min(
                       {0.1 * std::abs(center - x) + 15,
                        0.08 * std::min(x, world.getWidth() - x) + 5,
                        50.0}) *
                       rnd.getCoarseNoise(x, 0);
        world.getSurfaceLevel(x) = curY;
        if (delta == curY - prevY) {
            ++deltaLen;
        } else {
            if (deltaLen > 4 && (delta == 1 || delta == -1)) {
                // Break up boring slopes.
                for (int i = 0; i < deltaLen; ++i) {
                    world.getSurfaceLevel(x - i) +=
                        9 * (0.5 - std::abs(i - 0.5 * deltaLen) / deltaLen) *
                        rnd.getFineNoise(x - 2 * i, 0);
                }
            }
            delta = curY - prevY;
            deltaLen = 1;
        }
        prevY = curY;
    }
}

void scatterResource(Random &rnd, World &write_world, const World &read_world, int resource)
{
    rnd.shuffleNoise();
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = 0; x < read_world.getWidth(); ++x) {
        for (int y = 0; y < read_world.getHeight(); ++y) {
            if (rnd.getFineNoise(x, y) > 0.7) {
                const Tile &readTile = read_world.getTile(x, y);
                Tile &writeTile = write_world.getTile(x, y);
                writeTile = readTile;
                if (writeTile.blockID != TileID::empty) {
                    writeTile.blockID = resource;
                }
            }
        }
    }
}

void genOreVeins(Random &rnd, World &write_world, const World &read_world, int oreRoof, int oreFloor, int ore)
{
    rnd.shuffleNoise();
    double threshold = computeOreThreshold(write_world.conf.ore);
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = 0; x < write_world.getWidth(); ++x) {
        for (int y = oreRoof; y < oreFloor; ++y) {
            if (rnd.getFineNoise(x, y) < threshold) {
                const Tile &readTile = read_world.getTile(x, y);
                if (readTile.blockID != TileID::empty) {
                    Tile &writeTile = write_world.getTile(x, y);
                    writeTile = readTile;
                    writeTile.blockID = ore;
                }
            }
        }
    }
}

void genWorldBase(Random &rnd, World &write_world, const World &read_world)
{
    std::cout << "Generating base terrain\n";
    std::vector<std::tuple<int, int, int>> wallVarNoise;
    for (int wallId : WallVariants::dirt) {
        wallVarNoise.emplace_back(
            rnd.getInt(0, read_world.getWidth()),
            rnd.getInt(0, read_world.getHeight()),
            wallId);
    }
    computeSurfaceLevel(rnd, write_world);
    write_world.spawnY = write_world.getSurfaceLevel(write_world.getWidth() / 2) - 1;
    // Fill the world with dirt and stone; mostly dirt near the surface,
    // transitioning to mostly stone deeper down.
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = 0; x < read_world.getWidth(); ++x) {
        // Skip background wall for the first tile in every column.
        bool placeWalls = false;
        for (int y = read_world.getSurfaceLevel(x); y < read_world.getHeight(); ++y) {
            double threshold =
                y < read_world.getUndergroundLevel()
                    ? 3.0 * y / read_world.getUndergroundLevel() - 3
                    : static_cast<double>(y - read_world.getUndergroundLevel()) /
                          (read_world.getHeight() - read_world.getUndergroundLevel());
            Tile &tile = write_world.getTile(x, y);
            tile.blockID = rnd.getFineNoise(x, y) > threshold
                               ? TileID::dirt
                               : TileID::stone;
            if (placeWalls) {
                for (auto [i, j, wallId] : wallVarNoise) {
                    // Patches of dirt wall variants.
                    if (std::abs(rnd.getCoarseNoise(x + i, y + j)) < 0.07) {
                        tile.wallID = wallId;
                        break;
                    }
                }
                if (tile.wallID == WallID::empty &&
                    y < read_world.getUndergroundLevel()) {
                    tile.wallID = tile.blockID == TileID::stone
                                      ? WallID::Unsafe::rockyDirt
                                      : WallID::Unsafe::dirt;
                }
            } else {
                placeWalls = true;
            }
        }
    }

    scatterResource(rnd, write_world, read_world, TileID::clay);
    scatterResource(rnd, write_world, read_world, TileID::sand);
    scatterResource(rnd, write_world, read_world, TileID::mud);

    int underworldHeight = read_world.getHeight() - read_world.getUnderworldLevel();
    std::map<int, int> underworldWalls{{WallID::empty, WallID::empty}};
    for (int wallId : WallVariants::dirt) {
        underworldWalls[wallId] = rnd.select(WallVariants::underworld);
    }
    double hellstoneThreshold = -computeOreThreshold(4.24492 * read_world.conf.ore);
    
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = 0; x < read_world.getWidth(); ++x) {
        int underworldRoof =
            read_world.getUnderworldLevel() + 0.22 * underworldHeight +
            19 * rnd.getCoarseNoise(x, 0.33 * read_world.getHeight());
        int underworldFloor =
            read_world.getUnderworldLevel() + 0.42 * underworldHeight +
            35 * rnd.getCoarseNoise(x, 0.66 * read_world.getHeight());
        for (int y =
                 read_world.getUnderworldLevel() + 20 * rnd.getCoarseNoise(x, 0);
             y < read_world.getHeight();
             ++y) {
            // Fill underworld with ash, with an empty band across the
            // entire middle.
            Tile &tile = write_world.getTile(x, y);
            if (y > underworldFloor) {
                tile.blockID =
                    std::abs(rnd.getFineNoise(x, y)) > hellstoneThreshold
                        ? TileID::hellstone
                        : TileID::ash;
            } else {
                tile.blockID =
                    y < underworldRoof ? TileID::ash : TileID::empty;
            }
            tile.wallID = underworldWalls[tile.wallID];
        }
    }

    std::cout << "Generating ore veins\n";
    // Add ore deposits in overlapping bands; more valuable ore bands are
    // deeper.
    genOreVeins(
        rnd,
        write_world,
        read_world,
        0.6 * write_world.getUndergroundLevel(),
        (write_world.getUndergroundLevel() + write_world.getCavernLevel()) / 2,
        write_world.copperVariant);
    genOreVeins(
        rnd,
        write_world,
        read_world,
        0.85 * write_world.getUndergroundLevel(),
        (2 * write_world.getCavernLevel() + write_world.getUnderworldLevel()) / 3,
        write_world.ironVariant);
    genOreVeins(
        rnd,
        write_world,
        read_world,
        (write_world.getUndergroundLevel() + write_world.getCavernLevel()) / 2,
        (write_world.getCavernLevel() + write_world.getUnderworldLevel()) / 2,
        write_world.silverVariant);
    genOreVeins(
        rnd,
        write_world,
        read_world,
        (2 * write_world.getCavernLevel() + write_world.getUnderworldLevel()) / 3,
        write_world.getUnderworldLevel(),
        write_world.goldVariant);

    std::cout << "Digging caves\n";
    rnd.shuffleNoise();
    // Save so later generators can match cave structures.
    rnd.saveShuffleState();
    std::mutex ptMtx;
    std::vector<std::pair<int, int>> isolatedPoints;
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = 0; x < read_world.getWidth(); ++x) {
        bool nearEdge = x < 350 || x > read_world.getWidth() - 350;
        int scanState = 0;
        std::vector<std::pair<int, int>> candidates;
        for (int y = 0; y < read_world.getHeight(); ++y) {
            if (nearEdge && y < 0.9 * read_world.getUndergroundLevel()) {
                continue;
            }
            double threshold =
                y < read_world.getUndergroundLevel()
                    ? 2.94 - 3.1 * y / read_world.getUndergroundLevel()
                : y > read_world.getUnderworldLevel()
                    ? 3.1 * (y - read_world.getUnderworldLevel()) /
                              underworldHeight -
                          0.16
                    : -0.16;
            bool isEmpty = false;
            if (std::abs(rnd.getCoarseNoise(x, 2 * y) + 0.1) < 0.15 &&
                rnd.getFineNoise(x, y) > threshold) {
                // Strings of nearly connected caves, with horizontal bias.
                Tile &tile = write_world.getTile(x, y);
                tile.blockID = TileID::empty;
                isEmpty = true;
            }
            threshold =
                y > read_world.getUnderworldLevel()
                    ? (read_world.getUnderworldLevel() - y) / 10.0
                    : static_cast<double>(y - read_world.getUndergroundLevel()) /
                              (read_world.getUnderworldLevel() -
                               read_world.getUndergroundLevel()) -
                          1;
            if (std::abs(rnd.getCoarseNoise(x, 2 * y)) > 0.55 &&
                rnd.getFineNoise(x, y) < threshold + 0.1) {
                // Increasingly large isolated deep caves.
                Tile &tile = write_world.getTile(x, y);
                tile.blockID = TileID::empty;
                isEmpty = true;
            }
            switch (scanState) {
            case 0:
                if (isEmpty) {
                    scanState = 1;
                }
                break;
            case 1:
                if (!isEmpty) {
                    scanState = 2;
                }
                break;
            case 2:
                if (isEmpty) {
                    scanState = 1;
                    candidates.emplace_back(x, y - 1);
                } else {
                    scanState = 0;
                }
                break;
            }
        }
        if (!candidates.empty()) {
            std::lock_guard lock{ptMtx};
            isolatedPoints.insert(
                isolatedPoints.end(),
                candidates.begin(),
                candidates.end());
        }
    }
    for (auto [x, y] : isolatedPoints) {
        if (write_world.isIsolated(x, y)) {
            write_world.getTile(x, y).blockID = TileID::empty;
            continue;
        }
    }
}
