#ifndef ASHENFIELD_H
#define ASHENFIELD_H

class World;
class Random;

void genAshenField(Random &rnd, World &write_world, const World &read_world);

#endif // ASHENFIELD_H
