#ifndef BASE_H
#define BASE_H

class World;
class Random;

void computeSurfaceLevel(Random &rnd, World &world);
void genWorldBase(Random &rnd, World &write_world, const World &read_world);

#endif // BASE_H
