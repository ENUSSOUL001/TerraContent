#include "Snow.h"

#include "Config.h"
#include "Random.h"
#include "Util.h"
#include "World.h"
#include "ids/WallID.h"
#include <iostream>
#include <map>

void genSnow(Random &rnd, World &write_world, const World &read_world)
{
    std::cout << "Freezing land\n";
    rnd.shuffleNoise();
    double center = write_world.snowCenter;
    double scanDist = write_world.conf.snowSize * 0.08 * write_world.getWidth();
    double snowFloor =
        (write_world.getCavernLevel() + 2 * write_world.getUnderworldLevel()) / 3;
    std::map<int, int> snowWalls{{WallID::Safe::cloud, WallID::Safe::cloud}};
    for (int wallId : WallVariants::dirt) {
        snowWalls[wallId] = rnd.select(
            {WallID::Unsafe::snow,
             WallID::Unsafe::snow,
             WallID::Unsafe::ice,
             WallID::Unsafe::ice,
             rnd.select(WallVariants::stone)});
    }
    int startX = std::max<int>(center - scanDist, 0);
    int endX = std::min<int>(center + scanDist, write_world.getWidth());
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = startX; x < endX; ++x) {
        for (int y = 0; y < write_world.getUnderworldLevel(); ++y) {
            double threshold = std::max(
                std::abs(x - center) / 100.0 -
                    (write_world.conf.snowSize * write_world.getWidth() / 1700.0),
                15 * (y - snowFloor) / write_world.getHeight());
            if (rnd.getCoarseNoise(x, y) < threshold) {
                continue;
            }
            const Tile &readTile = read_world.getTile(x, y);
            Tile &writeTile = write_world.getTile(x, y);
            writeTile = readTile;
            
            switch (writeTile.blockID) {
            case TileID::dirt:
            case TileID::smoothMarble:
                writeTile.blockID = TileID::snow;
                writeTile.wallID = WallID::Unsafe::snow;
                break;
            case TileID::stone:
                writeTile.blockID = TileID::ice;
                writeTile.wallID = WallID::Unsafe::ice;
                break;
            case TileID::clay:
                writeTile.blockID = TileID::stone;
                break;
            case TileID::sand:
                writeTile.blockID = TileID::thinIce;
                break;
            case TileID::mud:
                writeTile.blockID = TileID::slush;
                break;
            case TileID::cloud:
                writeTile.blockID = TileID::snowCloud;
                break;
            default:
                break;
            }
            auto itr = snowWalls.find(writeTile.wallID);
            if (itr != snowWalls.end()) {
                writeTile.wallID = itr->second;
            }
            threshold = std::max(
                threshold,
                15.0 * (write_world.getCavernLevel() - y) / write_world.getHeight());
            if (std::abs(rnd.getCoarseNoise(2 * x, y) + 0.1) < 0.12 &&
                rnd.getFineNoise(x, y) > std::max(-0.1, 1 + threshold)) {
                writeTile.blockID = writeTile.blockID == TileID::snow
                                   ? TileID::thinIce
                                   : TileID::empty;
            }
        }
    }
}
