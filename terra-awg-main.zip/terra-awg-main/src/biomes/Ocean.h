#ifndef OCEAN_H
#define OCEAN_H

class World;
class Random;

void genOceans(Random &rnd, World &write_world, const World &read_world);

#endif // OCEAN_H
