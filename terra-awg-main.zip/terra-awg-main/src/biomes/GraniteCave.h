#ifndef GRANITECAVE_H
#define GRANITECAVE_H

class World;
class Random;

void genGraniteCave(Random &rnd, World &world);

#endif // GRANITECAVE_H
