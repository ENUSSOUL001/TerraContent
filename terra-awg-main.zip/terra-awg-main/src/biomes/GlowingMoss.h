#ifndef GLOWINGMOSS_H
#define GLOWINGMOSS_H

class World;
class Random;

void genGlowingMoss(Random &rnd, World &world);

#endif // GLOWINGMOSS_H
