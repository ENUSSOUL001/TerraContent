#ifndef DOUBLETROUBLE_CRIMSON_H
#define DOUBLETROUBLE_CRIMSON_H

class World;
class Random;

void genSecondaryCrimson(Random &rnd, World &write_world, const World &read_world);

#endif // DOUBLETROUBLE_CRIMSON_H
