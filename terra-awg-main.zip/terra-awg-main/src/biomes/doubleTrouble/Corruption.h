#ifndef DOUBLETROUBLE_CORRUPTION_H
#define DOUBLETROUBLE_CORRUPTION_H

class World;
class Random;

void genSecondaryCorruption(Random &rnd, World &write_world, const World &read_world);

#endif // DOUBLETROUBLE_CORRUPTION_H
