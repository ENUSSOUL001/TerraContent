#ifndef DOUBLETROUBLE_RESOURCESWAP_H
#define DOUBLETROUBLE_RESOURCESWAP_H

class World;
class Random;

void swapResources(Random &rnd, World &world);

#endif // DOUBLETROUBLE_RESOURCESWAP_H
