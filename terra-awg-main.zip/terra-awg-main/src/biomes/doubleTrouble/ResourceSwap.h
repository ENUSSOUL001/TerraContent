#ifndef DOUBLETROUBLE_RESOURCESWAP_H
#define DOUBLETROUBLE_RESOURCESWAP_H

class World;
class Random;

void swapResources(Random &rnd, World &write_world, const World &read_world);

#endif // DOUBLETROUBLE_RESOURCESWAP_H
