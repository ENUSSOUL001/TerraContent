#include "biomes/doubleTrouble/ResourceSwap.h"

#include "Random.h"
#include "Util.h"
#include "World.h"
#include "ids/WallID.h"
#include "vendor/frozen/map.h"
#include <iostream>

void swapResources(Random &rnd, World &write_world, const World &read_world)
{
    std::cout << "Shuffling ores\n";
    rnd.restoreShuffleState();
    constexpr auto oreSwap = frozen::make_map<int, int>({
        {TileID::copperOre, TileID::tinOre},
        {TileID::tinOre, TileID::copperOre},
        {TileID::ironOre, TileID::leadOre},
        {TileID::leadOre, TileID::ironOre},
        {TileID::silverOre, TileID::tungstenOre},
        {TileID::tungstenOre, TileID::silverOre},
        {TileID::goldOre, TileID::platinumOre},
        {TileID::platinumOre, TileID::goldOre},
        {TileID::cobaltOre, TileID::palladiumOre},
        {TileID::palladiumOre, TileID::cobaltOre},
        {TileID::mythrilOre, TileID::orichalcumOre},
        {TileID::orichalcumOre, TileID::mythrilOre},
        {TileID::adamantiteOre, TileID::titaniumOre},
        {TileID::titaniumOre, TileID::adamantiteOre},
    });
    constexpr auto blockSwap = frozen::make_map<int, int>({
        {TileID::marble, TileID::granite},
        {TileID::granite, TileID::marble},
        {TileID::smoothMarble, TileID::smoothGranite},
        {TileID::smoothGranite, TileID::smoothMarble},
    });
    constexpr auto wallSwap = frozen::make_map<int, int>({
        {WallID::Unsafe::marble, WallID::Unsafe::granite},
        {WallID::Unsafe::granite, WallID::Unsafe::marble},
    });
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = 0; x < read_world.getWidth(); ++x) {
        for (int y = 0; y < read_world.getHeight(); ++y) {
            const Tile &readTile = read_world.getTile(x, y);
            Tile &writeTile = write_world.getTile(x, y);
            writeTile = readTile;
            
            auto blockItr = blockSwap.find(writeTile.blockID);
            if (blockItr != blockSwap.end()) {
                writeTile.blockID = blockItr->second;
            } else if (rnd.getCoarseNoise(x, y) > 0) {
                auto oreItr = oreSwap.find(writeTile.blockID);
                if (oreItr != oreSwap.end()) {
                    writeTile.blockID = oreItr->second;
                }
            }
            auto wallItr = wallSwap.find(writeTile.wallID);
            if (wallItr != wallSwap.end()) {
                writeTile.wallID = wallItr->second;
            }
        }
    }
}
