#ifndef GEMGROVE_H
#define GEMGROVE_H

class World;
class Random;

void genGemGrove(Random &rnd, World &write_world, const World &read_world);

#endif // GEMGROVE_H
