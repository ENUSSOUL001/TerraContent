#ifndef DESERT_H
#define DESERT_H

class World;
class Random;

void genDesert(Random &rnd, World &world);

#endif // DESERT_H
