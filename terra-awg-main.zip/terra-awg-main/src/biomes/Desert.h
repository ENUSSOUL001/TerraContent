#ifndef DESERT_H
#define DESERT_H

class World;
class Random;

void genDesert(Random &rnd, World &write_world, const World &read_world);

#endif // DESERT_H
