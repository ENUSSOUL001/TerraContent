#ifndef JUNGLE_H
#define JUNGLE_H

class World;
class Random;

void levitateIslands(int lb, int ub, Random &rnd, World &world);
void genJungle(Random &rnd, World &write_world, const World &read_world);

#endif // JUNGLE_H
