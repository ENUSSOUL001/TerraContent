#ifndef HIVEQUEEN_GLOWINGMUSHROOM_H
#define HIVEQUEEN_GLOWINGMUSHROOM_H

class World;
class Random;

void genGlowingMushroomHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_GLOWINGMUSHROOM_H
