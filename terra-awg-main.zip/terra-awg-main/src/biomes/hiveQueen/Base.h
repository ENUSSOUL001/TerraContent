#ifndef HIVEQUEEN_BASE_H
#define HIVEQUEEN_BASE_H

class World;
class Random;

void genWorldBaseHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_BASE_H
