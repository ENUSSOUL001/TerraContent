#ifndef HIVEQUEEN_AETHER_H
#define HIVEQUEEN_AETHER_H

class World;
class Random;

void genAetherHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_AETHER_H
