#ifndef HIVEQUEEN_GRANITECAVE_H
#define HIVEQUEEN_GRANITECAVE_H

class World;
class Random;

void genGraniteCaveHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_GRANITECAVE_H
