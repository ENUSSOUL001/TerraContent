#ifndef SPIDERNEST_H
#define SPIDERNEST_H

class World;
class Random;

void genSpiderNest(Random &rnd, World &world);

#endif // SPIDERNEST_H
