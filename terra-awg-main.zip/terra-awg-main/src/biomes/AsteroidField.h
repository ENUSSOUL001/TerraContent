#ifndef ASTEROIDFIELD_H
#define ASTEROIDFIELD_H

class World;
class Random;

void genAsteroidField(Random &rnd, World &write_world, const World &read_world);

#endif // ASTEROIDFIELD_H
