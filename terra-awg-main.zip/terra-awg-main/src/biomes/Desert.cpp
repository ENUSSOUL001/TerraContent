#include "Desert.h"

#include "Config.h"
#include "Random.h"
#include "Util.h"
#include "World.h"
#include "biomes/BiomeUtil.h"
#include "ids/WallID.h"
#include <iostream>
#include <map>

void genDesert(Random &rnd, World &write_world, const World &read_world)
{
    std::cout << "Desertification\n";
    rnd.shuffleNoise();
    int noiseShuffleX = rnd.getInt(0, write_world.getWidth());
    int noiseShuffleY = rnd.getInt(0, write_world.getHeight());
    double center = write_world.desertCenter;
    double scanDist = write_world.conf.desertSize * 0.08 * write_world.getWidth();
    double desertFloor =
        (write_world.getCavernLevel() + 4 * write_world.getUnderworldLevel()) / 5;
    std::map<int, int> sandWalls{
        {WallID::Unsafe::marble, WallID::Unsafe::marble},
        {WallID::Safe::cloud, WallID::Safe::cloud}};
    for (int wallId : WallVariants::dirt) {
        sandWalls[wallId] = rnd.select(
            {WallID::Unsafe::sandstone, WallID::Unsafe::hardenedSand});
    }
    fillLargeWallGaps(
        {center - 0.9 * scanDist, 0.95 * write_world.getUndergroundLevel()},
        {center + 0.9 * scanDist, 0.96 * desertFloor},
        rnd,
        write_world);
    int startX = std::max<int>(center - scanDist, 0);
    int endX = std::min<int>(center + scanDist, write_world.getWidth());
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = startX; x < endX; ++x) {
        for (int y = 0; y < write_world.getUnderworldLevel(); ++y) {
            double threshold = std::max(
                std::abs(x - center) / 100.0 -
                    (write_world.conf.desertSize * write_world.getWidth() / 1700.0),
                15 * (y - desertFloor) / write_world.getHeight());
            if (rnd.getCoarseNoise(x, y) < threshold) {
                continue;
            }
            const Tile &readTile = read_world.getTile(x, y);
            Tile &writeTile = write_world.getTile(x, y);
            writeTile = readTile;
            
            switch (writeTile.blockID) {
            case TileID::dirt:
                writeTile.blockID = TileID::sand;
                break;
            case TileID::ice:
                if (rnd.getFineNoise(x, y) > -0.02) {
                    break;
                }
                [[fallthrough]];
            case TileID::stone:
            case TileID::smoothMarble:
                writeTile.blockID = TileID::sandstone;
                if (y > write_world.getCavernLevel()) {
                    if (std::abs(rnd.getCoarseNoise(x, y) + 0.23) < 0.04) {
                        writeTile.blockID = TileID::sand;
                    } else if (
                        std::abs(rnd.getCoarseNoise(x, y) - 0.23) < 0.04) {
                        writeTile.blockID = TileID::hardenedSand;
                    }
                }
                break;
            case TileID::clay:
            case TileID::mud:
                writeTile.blockID = TileID::desertFossil;
                break;
            case TileID::sand:
                writeTile.blockID =
                    y > write_world.getCavernLevel()        ? TileID::desertFossil
                    : y > write_world.getUndergroundLevel() ? TileID::hardenedSand
                                                      : TileID::sand;
                break;
            default:
                break;
            }
            if (writeTile.blockID == TileID::sandstone) {
                writeTile.wallID = WallID::Unsafe::sandstone;
            } else if (
                writeTile.blockID == TileID::sand ||
                writeTile.blockID == TileID::hardenedSand) {
                writeTile.wallID = WallID::Unsafe::hardenedSand;
            } else {
                writeTile.wallID = sandWalls[writeTile.wallID];
            }

            threshold = std::max(
                threshold,
                3.0 * (write_world.getUndergroundLevel() - y) /
                    write_world.getHeight());
            bool shouldClear =
                std::abs(rnd.getBlurNoise(x, 5 * y)) >
                    std::max(threshold + 1.2, 0.4) &&
                rnd.getFineNoise(noiseShuffleX + x, noiseShuffleY + y) >
                    -0.3;
            if (shouldClear && (writeTile.blockID == TileID::sandstone ||
                                ((writeTile.blockID == TileID::sand ||
                                  writeTile.blockID == TileID::hardenedSand) &&
                                 rnd.getFineNoise(x, y) > 0))) {
                writeTile.blockID = TileID::empty;
            }
            if (writeTile.wallID == WallID::empty &&
                y > write_world.getCavernLevel() &&
                rnd.getFineNoise(x, y) < 0.5) {
                writeTile.wallID = WallID::Unsafe::sandstone;
            }
        }
    }
}
