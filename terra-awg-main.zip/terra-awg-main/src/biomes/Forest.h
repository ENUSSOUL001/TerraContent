#ifndef FOREST_H
#define FOREST_H

class World;
class Random;

void genForest(Random &rnd, World &write_world, const World &read_world);

#endif // FOREST_H
