#ifndef MARBLECAVE_H
#define MARBLECAVE_H

class World;
class Random;

void genMarbleCave(Random &rnd, World &world);

#endif // MARBLECAVE_H
