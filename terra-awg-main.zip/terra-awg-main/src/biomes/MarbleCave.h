#ifndef MARBLECAVE_H
#define MARBLECAVE_H

class World;
class Random;

void genMarbleCave(Random &rnd, World &write_world, const World &read_world);

#endif // MARBLECAVE_H
