#ifndef AETHER_H
#define AETHER_H

class World;
class Random;

void genAether(Random &rnd, World &write_world, const World &read_world);

#endif // AETHER_H
