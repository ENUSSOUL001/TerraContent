#include "biomes/hardmode/HmOres.h"

#include "Config.h"
#include "Random.h"
#include "Util.h"
#include "World.h"
#include "biomes/BiomeUtil.h"
#include "vendor/frozen/set.h"
#include <iostream>

bool canSpawnChlorophyte(int x, int y, World &world)
{
    int radius = 8;
    for (int i = -radius; i < radius; ++i) {
        for (int j = -radius; j < radius; ++j) {
            if (std::hypot(i, j) < radius) {
                Tile &tile = world.getTile(x + i, y + j);
                if (tile.blockID == TileID::jungleGrass ||
                    tile.blockID == TileID::chlorophyteOre) {
                    return true;
                }
            }
        }
    }
    return false;
}

struct DepositDef {
    int ore;
    int minY;
    int maxY;
    int noiseX;
    int noiseY;
};

void genHardmodeOres(Random &rnd, World &write_world, const World &read_world)
{
    std::cout << "Blessing ore\n";
    rnd.shuffleNoise();
    constexpr auto clearableTiles = frozen::make_set<int>({
        TileID::ash,
        TileID::clay,
        TileID::corruptIce,
        TileID::corruptJungleGrass,
        TileID::crimsand,
        TileID::crimsandstone,
        TileID::crimsonIce,
        TileID::crimsonJungleGrass,
        TileID::crimstone,
        TileID::dirt,
        TileID::ebonsand,
        TileID::ebonsandstone,
        TileID::ebonstone,
        TileID::granite,
        TileID::hardenedCrimsand,
        TileID::hardenedEbonsand,
        TileID::hardenedSand,
        TileID::ice,
        TileID::jungleGrass,
        TileID::marble,
        TileID::mud,
        TileID::mushroomGrass,
        TileID::sand,
        TileID::sandstone,
        TileID::snow,
        TileID::stone,
    });
    std::array<DepositDef, 3> depositNoise({
        {read_world.cobaltVariant,
         0,
         static_cast<int>(std::lerp(
             read_world.getCavernLevel(),
             read_world.getUnderworldLevel(),
             0.48)),
         rnd.getInt(0, read_world.getWidth()),
         rnd.getInt(0, read_world.getHeight())},
        {read_world.mythrilVariant,
         static_cast<int>(std::lerp(
             read_world.getCavernLevel(),
             read_world.getUnderworldLevel(),
             0.12)),
         static_cast<int>(std::lerp(
             read_world.getCavernLevel(),
             read_world.getUnderworldLevel(),
             0.73)),
         rnd.getInt(0, read_world.getWidth()),
         rnd.getInt(0, read_world.getHeight())},
        {read_world.adamantiteVariant,
         static_cast<int>(std::lerp(
             read_world.getCavernLevel(),
             read_world.getUnderworldLevel(),
             0.61)),
         read_world.getHeight(),
         rnd.getInt(0, read_world.getWidth()),
         rnd.getInt(0, read_world.getHeight())},
    });
    double chlorophyteThreshold = computeOreThreshold(0.7 * read_world.conf.ore);
    double oreThreshold = computeOreThreshold(0.9 * read_world.conf.ore);
    #pragma omp parallel for schedule(dynamic) firstprivate(rnd)
    for (int x = 0; x < read_world.getWidth(); ++x) {
            for (int y = 0; y < read_world.getHeight(); ++y) {
                const Tile &readTile = read_world.getTile(x, y);
                Tile &writeTile = write_world.getTile(x, y);
                writeTile = readTile;
                
                if (!clearableTiles.contains(writeTile.blockID) ||
                    (y > read_world.getUnderworldLevel() &&
                     writeTile.blockID == TileID::ash)) {
                    continue;
                }
                if (y > read_world.getUndergroundLevel() &&
                    rnd.getFineNoise(x, y) < chlorophyteThreshold) {
                    if (writeTile.blockID == TileID::jungleGrass ||
                        (writeTile.blockID == TileID::mud &&
                         canSpawnChlorophyte(x, y, const_cast<World&>(read_world)))) {
                        writeTile.blockID = TileID::chlorophyteOre;
                        continue;
                    }
                }
                if (rnd.getCoarseNoise(x, y) < 0.13) {
                    continue;
                }
                for (const auto &row : depositNoise) {
                    if (y > row.minY && y < row.maxY &&
                        rnd.getFineNoise(x + row.noiseX, y + row.noiseY) <
                            oreThreshold) {
                        writeTile.blockID = row.ore;
                        break;
                    }
                }
            }
    }
}
