#ifndef HALLOW_H
#define HALLOW_H

class World;
class Random;

void genHallow(Random &rnd, World &write_world, const World &read_world);

#endif // HALLOW_H
