#ifndef HALLOW_H
#define HALLOW_H

class World;
class Random;

void genHallow(Random &rnd, World &world);

#endif // HALLOW_H
