#include "biomes/AsteroidField.h"

#include "Config.h"
#include "Random.h"
#include "World.h"
#include "ids/Paint.h"
#include <iostream>

std::pair<int, int>
selectAsteroidFieldLocation(int &width, int height, Random &rnd, World &world)
{
    int y = 40;
    double widthF = width;
    double widthDelta = widthF / 2500;
    while (true) {
        int x =
            rnd.getInt(40, std::max<int>(0.3 * world.getWidth() - widthF, 45));
        if (rnd.getBool()) {
            x = world.getWidth() - x - widthF;
        }
        if (world.regionPasses(
                x + 0.1 * widthF,
                y,
                0.8 * widthF,
                height,
                [](Tile &tile) { return tile.blockID == TileID::empty; })) {
            width = std::midpoint<int>(width, widthF);
            return {x, y};
        }
        widthF -= widthDelta;
    }
}

void genAsteroidField(Random &rnd, World &write_world, const World &read_world)
{
    std::cout << "Suspending asteroids\n";
    int width =
        write_world.conf.asteroids * rnd.getDouble(0.06, 0.07) * write_world.getWidth();
    int height = rnd.getDouble(0.18, 0.21) * write_world.getUndergroundLevel();
    auto [fieldX, fieldY] =
        selectAsteroidFieldLocation(width, height, rnd, write_world);
    int numAsteroids = width * height / 220;
    for (int tries = 10 * numAsteroids; numAsteroids > 0 && tries > 0;
         --tries) {
        double radius = rnd.getDouble(2, 9);
        int x = rnd.getInt(fieldX + radius, fieldX + width - radius);
        int y = rnd.getInt(fieldY + radius, fieldY + height - radius);
        double centerDist = std::hypot(
            (fieldX + 0.5 * width - x) / width,
            (fieldY + 0.5 * height - y) / height);
        if ((centerDist > 0.48 && fnv1a32pt(x, y) % 11 != 0) ||
            !read_world.regionPasses(
                x - radius,
                y - radius,
                2 * radius + 0.5,
                2 * radius + 0.5,
                [](const Tile &tile) { return tile.blockID == TileID::empty; })) {
            continue;
        }
        int paint = rnd.select({Paint::brown, Paint::black});
        for (int i = -radius; i < radius; ++i) {
            for (int j = -radius; j < radius; ++j) {
                if (std::hypot(i, j) / radius <
                    0.6 + 0.6 * rnd.getFineNoise(x + i, y + j)) {
                    const Tile &readTile = read_world.getTile(x + i, y + j);
                    Tile &writeTile = write_world.getTile(x + i, y + j);
                    writeTile = readTile;
                    writeTile.blockID =
                        std::min(
                            std::abs(rnd.getFineNoise(x + i, j + radius)),
                            std::abs(rnd.getFineNoise(i + radius, y + j))) <
                                0.03
                            ? TileID::meteorite
                            : TileID::stone;
                    writeTile.blockPaint = paint;
                }
            }
        }
        --numAsteroids;
    }
    for (int i = 0; i < width; ++i) {
        for (int j = 0; j < height; ++j) {
            const Tile &readTile = read_world.getTile(fieldX + i, fieldY + j);
            Tile &writeTile = write_world.getTile(fieldX + i, fieldY + j);
            writeTile = readTile;
            if ((writeTile.blockID == TileID::stone ||
                 writeTile.blockID == TileID::meteorite) &&
                read_world.isExposed(fieldX + i, fieldY + j)) {
                writeTile.actuated = true;
            }
        }
    }
}
