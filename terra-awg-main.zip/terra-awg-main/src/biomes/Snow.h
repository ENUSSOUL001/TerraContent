#ifndef SNOW_H
#define SNOW_H

class World;
class Random;

void genSnow(Random &rnd, World &write_world, const World &read_world);

#endif // SNOW_H
