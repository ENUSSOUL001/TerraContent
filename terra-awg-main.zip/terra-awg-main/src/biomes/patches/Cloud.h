#ifndef PATCHES_CLOUD_H
#define PATCHES_CLOUD_H

class World;
class Random;

void genCloudPatches(Random &rnd, World &write_world, const World &read_world);

#endif // PATCHES_CLOUD_H
