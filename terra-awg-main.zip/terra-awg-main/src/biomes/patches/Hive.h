#ifndef PATCHES_HIVE_H
#define PATCHES_HIVE_H

class World;
class Random;

void genHivePatches(Random &rnd, World &write_world, const World &read_world);

#endif // PATCHES_HIVE_H
