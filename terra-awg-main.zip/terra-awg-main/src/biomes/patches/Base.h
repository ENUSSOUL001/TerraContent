#ifndef PATCHES_BASE_H
#define PATCHES_BASE_H

class World;
class Random;

void genWorldBasePatches(Random &rnd, World &write_world, const World &read_world);

#endif // PATCHES_BASE_H
