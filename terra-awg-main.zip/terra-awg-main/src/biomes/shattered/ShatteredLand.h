#ifndef SHATTEREDLAND_H
#define SHATTEREDLAND_H

class World;
class Random;

void genShatteredLand(Random &rnd, World &write_world, const World &read_world);

#endif // SHATTEREDLAND_H
