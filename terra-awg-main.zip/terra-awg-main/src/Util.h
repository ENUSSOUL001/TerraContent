#ifndef UTIL_H
#define UTIL_H

#include <ranges>
#include <omp.h>

/**
 * Automatic thread management for parallel loop execution.
 *
 * Before:
 * @code
 * for (int i = 0; i < 100; ++i) {
 *     handleData(i);
 * }
 * @endcode
 *
 * After:
 * @code
 * parallelFor(std::views::iota(0, 100), [](int i) {
 *     handleData(i);
 * });
 * @endcode
 */
template <std::ranges::input_range R, class UnaryFunc>
void parallelFor(R &&r, UnaryFunc f)
{
    #pragma omp parallel for schedule(dynamic)
    for (auto val : r) {
        f(val);
    }
}

#endif // UTIL_H
