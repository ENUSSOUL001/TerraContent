#ifndef IMGWRITER_H
#define IMGWRITER_H

#include <string>

class World;

void savePreviewImage(std::string basename, World &world);

#endif // IMGWRITER_H
