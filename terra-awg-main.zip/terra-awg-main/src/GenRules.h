#ifndef GENRULES_H
#define GENRULES_H

class Random;
class World;

void doWorldGen(Random &rnd, World *write_world, World *read_world);

#endif // GENRULES_H
