#ifndef FOREST_H
#define FOREST_H

class World;
class Random;

void genForest(Random &rnd, World &world);

#endif // FOREST_H
