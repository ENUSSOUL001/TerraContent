#ifndef HIVEQUEEN_HIVE_H
#define HIVEQUEEN_HIVE_H

class World;
class Random;

void genHiveHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_HIVE_H
