#ifndef DOUBLETROUBLE_CORRUPTION_H
#define DOUBLETROUBLE_CORRUPTION_H

class World;
class Random;

void genSecondaryCorruption(Random &rnd, World &world);

#endif // DOUBLETROUBLE_CORRUPTION_H
