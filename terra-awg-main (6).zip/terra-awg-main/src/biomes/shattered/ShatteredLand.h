#ifndef SHATTEREDLAND_H
#define SHATTEREDLAND_H

class World;
class Random;

void genShatteredLand(Random &rnd, World &world);

#endif // SHATTEREDLAND_H
