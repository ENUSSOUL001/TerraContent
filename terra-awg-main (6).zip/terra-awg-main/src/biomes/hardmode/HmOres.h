#ifndef HMORES_H
#define HMORES_H

class World;
class Random;

void genHardmodeOres(Random &rnd, World &world);

#endif // HMORES_H
