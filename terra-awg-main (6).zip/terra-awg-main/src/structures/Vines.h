#ifndef VINES_H
#define VINES_H

class World;
class Random;

void genVines(Random &rnd, World &world);

#endif // VINES_H
