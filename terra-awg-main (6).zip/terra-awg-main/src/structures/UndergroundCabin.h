#ifndef UNDERGROUNDCABIN_H
#define UNDERGROUNDCABIN_H

class World;
class Random;

void maybePlaceCabinForChest(int x, int y, Random &rnd, World &world);

#endif // UNDERGROUNDCABIN_H
