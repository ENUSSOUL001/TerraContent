#ifndef OCEANWRECK_H
#define OCEANWRECK_H

class World;
class Random;

void genOceanWreck(Random &rnd, World &world);

#endif // OCEANWRECK_H
