#ifndef GLOBAL_HIVE_H
#define GLOBAL_HIVE_H

class World;

void genGlobalHive(World &world);

#endif // GLOBAL_HIVE_H
