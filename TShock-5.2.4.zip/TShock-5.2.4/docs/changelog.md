The changelog has moved to the wiki. In lieu of this, please put the text you want in the changelog in your PR description. It will be added to the wiki after we merge your PR.
