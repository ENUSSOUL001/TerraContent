#ifndef SNOW_H
#define SNOW_H

class World;
class Random;

void genSnow(Random &rnd, World &world);

#endif // SNOW_H
