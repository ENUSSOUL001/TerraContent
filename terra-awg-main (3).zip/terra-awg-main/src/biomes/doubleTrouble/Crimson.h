#ifndef DOUBLETROUBLE_CRIMSON_H
#define DOUBLETROUBLE_CRIMSON_H

class World;
class Random;

void genSecondaryCrimson(Random &rnd, World &world);

#endif // DOUBLETROUBLE_CRIMSON_H
