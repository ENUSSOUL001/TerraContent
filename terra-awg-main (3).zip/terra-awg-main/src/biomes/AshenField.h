#ifndef ASHENFIELD_H
#define ASHENFIELD_H

class World;
class Random;

void genAshenField(Random &rnd, World &world);

#endif // ASHENFIELD_H
