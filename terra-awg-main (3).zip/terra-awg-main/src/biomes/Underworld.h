#ifndef UNDERWORLD_H
#define UNDERWORLD_H

class World;
class Random;

void genUnderworld(Random &rnd, World &world);

#endif // UNDERWORLD_H
