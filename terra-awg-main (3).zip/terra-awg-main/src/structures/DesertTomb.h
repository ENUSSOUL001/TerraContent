#ifndef DESERTTOMB_H
#define DESERTTOMB_H

class World;
class Random;

void genDesertTomb(Random &rnd, World &world);

#endif // DESERTTOMB_H
