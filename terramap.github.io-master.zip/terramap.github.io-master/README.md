# TerraMap
TerraMap is an interactive Terraria v1.4.4 world map viewer that loads quickly and lets you pan, zoom, find blocks, ores, items in chests, dungeons, NPCs, etc.

This is the source code repository.  If you're looking for the web app, you can find it here: https://terramap.github.io

The web version of TerraMap is still experimental and feature incomplete.  Stay tuned for updates.

If you're looking for the much more functional (but Windows-only) app, you can find it here: https://terramap.github.io/windows.html
