!!!!!! PLEASE FILL IN THE TEMPLATE BELOW THANK YOU VERY MUCH !!!!!!

If you don't need help, delete this template and just post an issue (feature requests and discussions and the like).

* TShock version:
* TShock build number (if known):

#### Reproduction steps (if applicable)?

1. Some step
2. Some other step
3. Some bigger step
4. This is the problem

#### Any stack traces or error messages (if known)?

```
PUT SUPER LONG ERROR MESSAGES IN THE TICK MARKS
```

#### Any screenshots?

!!!!!! PLEASE FILL IN THE TEMPLATE ABOVE THANK YOU VERY MUCH !!!!!!