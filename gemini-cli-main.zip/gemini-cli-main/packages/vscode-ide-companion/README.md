# IDE Companion

## Local Development

To test the extension locally, follow these steps:

1. Open the `packages/vscode-ide-companion` directory in VS Code.
2. Run `npm install`.
3. Run the extension development host via Run + Debug -> Extension
