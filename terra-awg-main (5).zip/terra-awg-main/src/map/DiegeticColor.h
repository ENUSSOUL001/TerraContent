#ifndef DIEGETICCOLOR_H
#define DIEGETICCOLOR_H

class World;

int getSectorColor(int i, int j, int scale, World &world);

#endif // DIEGETICCOLOR_H
