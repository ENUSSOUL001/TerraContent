#ifndef PATCHES_JUNGLE_H
#define PATCHES_JUNGLE_H

class World;
class Random;

void genJunglePatches(Random &rnd, World &world);

#endif // PATCHES_JUNGLE_H
