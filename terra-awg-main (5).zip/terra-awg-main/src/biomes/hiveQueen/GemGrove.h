#ifndef HIVEQUEEN_GEMGROVE_H
#define HIVEQUEEN_GEMGROVE_H

class World;
class Random;

void genGemGroveHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_GEMGROVE_H
