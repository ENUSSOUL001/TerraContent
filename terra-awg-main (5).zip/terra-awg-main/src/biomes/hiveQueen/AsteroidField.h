#ifndef HIVEQUEEN_ASTEROIDFIELD_H
#define HIVEQUEEN_ASTEROIDFIELD_H

class World;
class Random;

void genAsteroidFieldHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_ASTEROIDFIELD_H
