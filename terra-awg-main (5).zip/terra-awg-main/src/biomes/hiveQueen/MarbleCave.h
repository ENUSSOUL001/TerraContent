#ifndef HIVEQUEEN_MARBLECAVE_H
#define HIVEQUEEN_MARBLECAVE_H

class World;
class Random;

void genMarbleCaveHiveQueen(Random &rnd, World &world);

#endif // HIVEQUEEN_MARBLECAVE_H
