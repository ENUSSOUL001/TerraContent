#ifndef OCEAN_H
#define OCEAN_H

class World;
class Random;

void genOceans(Random &rnd, World &world);

#endif // OCEAN_H
