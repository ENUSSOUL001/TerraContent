#ifndef TORCHARENA_H
#define TORCHARENA_H

class World;
class Random;

void genTorchArena(Random &rnd, World &world);

#endif // TORCHARENA_H
