#ifndef SPIDERHALL_H
#define SPIDERHALL_H

class World;
class Random;

void genSpiderHall(Random &rnd, World &world);

#endif // SPIDERHALL_H
